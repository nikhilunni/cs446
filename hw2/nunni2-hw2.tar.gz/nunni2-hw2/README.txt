Nikhil Unni
nunni2


For #1, I wrote a python script.
The script was written for Python 2.6
You can run it with (in bash):
python script1.py

Alternatively, you can run my BalloonTester.java, made with Weka, which has the same output but it's pretty ugly to read.


To run the Weka programs, you can go to the decision-trees folder, open test.sh, and uncomment out the line of the programs you want to run. I've annotated/separated by problem number. For example, one line has a comment #2c at the end, meaning that if you want to see my unbounded ID3 algorithm, you should comment that out.

Each of the programs writes to its corresponding data/2.X.pred file
